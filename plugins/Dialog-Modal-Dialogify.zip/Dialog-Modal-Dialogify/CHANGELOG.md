# Changelog

## 1.0.2
    add dialog style options
    add close button style options
    fix blurry render in some browser

## 1.0.1
    add global config
    add closeAll static method

## 1.0.0
    release